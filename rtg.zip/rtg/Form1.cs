﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace rtg
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            Form f2 = new Form2();
            this.AddOwnedForm(f2);
            
            
        }


   
        private void groupBox1_Enter(object sender, EventArgs e)
        {
           
        }

        private void toolStripComboBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 newform2 = new Form2();
            newform2.ShowDialog();
        }
    }
}
